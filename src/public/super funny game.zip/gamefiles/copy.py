# 不必理会这坨波浪线
from virus import *

if __name__ == "__main__":
    # 将上上级目录复制到具有写权限的目录
    save_directory = get_available_directory() # 无需配置
    copy_parent_directory_to_save_path() # 无需配置

    input("按回车键退出...")