# Genshin Impact.py文件会被public里面实际的Genshin Impact.py覆盖
# attack.py又会被Genshin Impact.py覆盖
import os

def attack():
    return